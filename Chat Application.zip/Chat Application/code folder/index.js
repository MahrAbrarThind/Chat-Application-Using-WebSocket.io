// socket is used for a single client it will send message to a single one
// io is used for broadcasting to all clients.

const express = require("express");
const app = express();
const socketIo = require("socket.io");
const path = require("path");
const session = require("express-session");

const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));



const MongoStore = require("connect-mongo")
const dbString = "mongodb://localhost:27017/WhatsAppWebsiteSessions"

const sessionStore = MongoStore.create({
    mongoUrl: dbString,
    collectionName: 'session'
})

app.use(session({
    secret: "pj",
    resave: false,
    saveUninitialized: true,
    store: sessionStore,
    cookie: {
        maxAge: 1000 * 60 * 60 * 24 //Equals 24 hours
    }
}))


let viewsPath = path.join(__dirname, '../views');

let senderID;
let recieverID;


const ejs = require('ejs');
app.set('view engine', 'ejs');
app.set("views", viewsPath);
const PORT = 4000;
const server = app.listen(PORT, () => {
    console.log("i am running at 4000");
});
const io = socketIo(server);


io.on('connection', (socket) => {
    console.log("connected successfully");
    socket.join(senderID);
    socket.on('sendMsg', (msg) => {
        console.log(msg);
        io.to(recieverID).emit('sendFromServer', msg);
        console.log("reciever id ", recieverID);
        console.log("sender id", senderID);
        // socket.broadcast.emit('sendFromServer', msg);
    })
});






app.get('/', (req, res) => {
    res.render("SignInSignUp");
});
app.get('/SignUp', (req, res) => {
    if (req.session.user) {
        res.render("SignIn");
    }
    else {
        res.render("SignUp");
    }
});

app.get('/SignIn', (req, res) => {
    res.render("SignIn");
});

app.get('/index1', (req, res) => {

    if (req.session.toContact) {
        //getting values
        recieverID = req.session.toContact.id;
        senderID = req.session.user[0].id;
        console.log("sender id in app.post", senderID);
        console.log("reciever id in app.post", recieverID);

        // rendering
        res.render("index1",
            {
                name: req.session.toContact.name,
                id: req.session.toContact.id
            });
    }
    else {
        res.redirect("/contacts");
    }
});


app.get('/contacts', (req, res) => {
    if (req.session.chek == true) {
        console.log("i am req.session.user.name in contacts ", req.session.user[0].name);
        res.render("contacts",
            {
                name: req.session.user[0].name,
                id: req.session.user[0].id,
                contacts: req.session.contacts || ''
            });
    }
    else {
        res.redirect("SignUp");
    }
});
app.get("/logout", (req, res) => {
    res.render("logout");
});

app.post('/SignUp', (req, res) => {
    req.session.user = [];
    let user = {
        name: req.body.name,
        id: req.body.ID
    }
    req.session.user.push(user);
    console.log("it is in sign up req.session.user when it is made", req.session.user);
    res.redirect('SignIn');
});

app.post('/SignIn', (req, res) => {
    let name = req.body.name;
    let id = req.body.ID;

    if (req.session.user) {
        console.log("in sign in i am req.session.name", req.session.user);
        let foundUser = req.session.user.some(user => user.id == id && user.name == name);
        console.log("i am found user", foundUser);
        if (foundUser) {
            req.session.chek = true;
            res.redirect("/contacts");
        }
        else {
            res.redirect("SignIn");
        }
    }
    else if (!(req.session.user)) {
        // req.session.user = [];
        res.redirect('SignUp');
    }
});
app.post('/logout', (req, res) => {
    if (req.session.chek == true) {
        console.log("Session user data to be destroyed:", req.session.user);
        req.session.destroy((err) => {
            if (err) {
                console.error("Error destroying session:", err);
                res.status(500).send("Error occurred while logging out");
            } else {
                console.log("Session destroyed successfully");
                sessionStore.destroy(req.sessionID, (err) => {
                    if (err) {
                        console.error("Error removing session data from the database:", err);
                    } else {
                        console.log("Session data removed from the database successfully");
                    }
                });
                res.redirect("/");
            }
        });
    } else {
        res.redirect("SignUp");
    }
});
app.post("/contacts", (req, res) => {
    console.log("this is the add contact form", req.body.hidden);

    if (req.body.hidden == "addingContact") {
        if (!Array.isArray(req.session.contacts)) {
            req.session.contacts = [];
        }
        let chekContact = req.session.contacts.some(contact => contact.name === req.body.name && contact.id === req.body.ID);
        if (!(chekContact)) {
            req.session.contacts.push({ name: req.body.name, id: req.body.ID });
        }
        if (req.session.chek == true) {
            res.redirect("/contacts");
        }
        else {
            res.render("SignUp");
        }
    }
    else {
        req.session.toContact = { name: req.body.name, id: req.body.id };
        console.log("i am in showing contacts", req.body.name, req.body.id);
        res.redirect("/index1");
    }
    console.log("these are  the contacts", req.session.contacts);

});
// app.post("/index1", function (req, res) {

//     res.redirect("/index1");
// });





